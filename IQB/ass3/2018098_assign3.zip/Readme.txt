Readme
-------

The code uses Balanced Bagging Classifier to balance the training data due to its unbalanced nature. Then it uses Support Vector Machine (SVM) to predict the test data and output to SVM_output.txt

Command to run:
python svm.py


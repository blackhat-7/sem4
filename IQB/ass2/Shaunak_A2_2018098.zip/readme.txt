 About the Assignment
---------------------

- Our submission uses SVM (Support Vector Machine) machine learning technique to predict AFP and non AFP.
- It uses the nucleotides into calculate the percentage of each of the 20 amino acids which is then passed as input to SVM library as X and y is the give label in train.csv
- Uses train.csv to train and tests on nucleotides from test.csv

How to run:
python SVMcode.py

Predicted output:
SVM_output.csv
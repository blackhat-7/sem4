# INSTRUCTIONS

-Type in the command line:
    python q#.py -i input_file -o output_file

-Replace # with question number eg. 1 or 2 or 3

-Specify the the respective file names in place of 'input_file' and 'output_file'
